package com.mydata.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mydata.mvc.model.UserLogin;
import com.mydata.mvc.repository.UserLoginRepository;

@Service
public class UserLoginServiceImpl implements UserLoginService
{
	@Autowired
	UserLoginRepository ulr;
	public void setUl(UserLoginRepository ulr) {
		this.ulr = ulr;
	}

	@Override
	public boolean validDataforLogin(String username, String password) 
	{		
		UserLogin ul= ulr.findById(username).orElse(null);
		return ul !=null && ul.getPassword().equals(password);
	}

}

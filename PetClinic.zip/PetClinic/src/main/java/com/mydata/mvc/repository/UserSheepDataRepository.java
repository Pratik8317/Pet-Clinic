package com.mydata.mvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mydata.mvc.model.UserSheepData;

public interface UserSheepDataRepository extends JpaRepository<UserSheepData, Integer>
{

}

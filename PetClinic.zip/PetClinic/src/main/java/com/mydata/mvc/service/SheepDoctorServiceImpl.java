package com.mydata.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mydata.mvc.model.SheepDoctor;
import com.mydata.mvc.repository.SheepDoctorRepository;

@Service
public class SheepDoctorServiceImpl implements SheepDoctorService{
	@Autowired
	SheepDoctorRepository adr;	
	public void setAdr(SheepDoctorRepository adr) {
		this.adr = adr;
	}


	@Override
	public void saveSheepDoctor(SheepDoctor sd) {
		adr.save(sd);
		
	}


	@Override
	public boolean validDataforSheep(String name, String password) {
		SheepDoctor sd=adr.findByUSername(name);
		if (sd!= null && sd.getPassword()!= null)
		{
			return sd.getPassword().equals(password);
		}
		else
		{
			return false;
		}
	}

}

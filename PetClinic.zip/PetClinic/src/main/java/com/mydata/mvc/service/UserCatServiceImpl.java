package com.mydata.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mydata.mvc.model.UserCatData;
import com.mydata.mvc.repository.UserCatDataRepository;

@Service
public class UserCatServiceImpl implements UserCatDataService
{
	@Autowired
	UserCatDataRepository uc;	
	public void setUc(UserCatDataRepository uc) {
		this.uc = uc;
	}


	@Override
	public void saveUserCat(UserCatData ucd) {
		uc.save(ucd);		
	}
	
	@Override
	public List<UserCatData> getAllCatProblem()
	{
		UserCatData data= (UserCatData) uc.findAll();
		System.out.println("Cat Problems: "+data.getId());
		return uc.findAll();
	}
}

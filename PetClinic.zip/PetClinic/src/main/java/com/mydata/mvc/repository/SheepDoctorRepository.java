package com.mydata.mvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mydata.mvc.model.SheepDoctor;

public interface SheepDoctorRepository extends JpaRepository<SheepDoctor, Integer>{
	@Query("SELECT s FROM SheepDoctor s WHERE s.name = :name")
	
	SheepDoctor findByUSername(String name);
}

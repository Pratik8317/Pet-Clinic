package com.mydata.mvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mydata.mvc.model.UserCatData;
import com.mydata.mvc.model.UserCowData;
import com.mydata.mvc.model.UserDogData;
import com.mydata.mvc.model.UserSheepData;
import com.mydata.mvc.service.UserCatDataService;
import com.mydata.mvc.service.UserCowDataService;
import com.mydata.mvc.service.UserDogDataService;
import com.mydata.mvc.service.UserSheepDataService;




@Controller
@RequestMapping(path="/")
public class UserPetDataController 
{ 
	// For Cat
	@Autowired
	UserCatDataService ucs;
	public void setUcs(UserCatDataService ucs) {
		this.ucs = ucs;
	}
	
	@RequestMapping(path="/openusercat")
	public String openUserCat(Model m)
	{
		UserCatData ucd=new UserCatData();
		m.addAttribute("cat", ucd);
		return "UserCat";
	}
	
	@RequestMapping(path="/savecatinfo")
	public String saveCatData(@ModelAttribute UserCatData uc)
	{
		ucs.saveUserCat(uc);
		return "UserHome";
	}
	
	@RequestMapping(path="/userhome")
	public String openUserHome()
	{
		return "UserHome";
	}
	
	@GetMapping(path="/fetchcatdoctorhome") // Fetch Cat Problems.
	public String fetchCatData(Model m)
	{
		List<UserCatData> catproblems=ucs.getAllCatProblem();
		System.out.println("Fecth Value: "+catproblems);
		m.addAttribute("catproblem", catproblems);
		System.out.println("Number of Cat Problems: "+catproblems.size());
		return "CatDoctorHome";
	}
	// For Dog 
	@Autowired
	UserDogDataService udds;
	public void setUdds(UserDogDataService udds) {
		this.udds = udds;
	}
	
	@RequestMapping(path="/openuserdog")
	public String openUserDog(Model m)
	{
		UserDogData udd=new UserDogData();
		m.addAttribute("dog", udd);
		return "UserDog";
	}
	
	@RequestMapping(path="/savedoginfo")
	public String saveDogData(@ModelAttribute UserDogData udd)
	{
		udds.saveUserDog(udd);
		return "UserHome";
	}
	
	// For Cow
	@Autowired
	UserCowDataService ucds;
	public void setUcds(UserCowDataService ucds) {
		this.ucds = ucds;
	}
	
	@RequestMapping(path="/openusercow")
	public String openUserCow(Model m)
	{
		UserCowData ucd=new UserCowData();
		m.addAttribute("cow",ucd);
		return "UserCow";
	}
	
	@RequestMapping(path="/savecowinfo")
	public String saveCowData(@ModelAttribute UserCowData ucd)
	{
		ucds.saveUserCow(ucd);
		return "UserHome";
	}
	
	// For Sheep
	@Autowired
	UserSheepDataService usds;
	public void setUsds(UserSheepDataService usds) {
		this.usds = usds;
	}

	@RequestMapping(path="/openusersheep")
	public String openUserSheep(Model m)
	{
		UserSheepData usd=new UserSheepData();
		m.addAttribute("sheep",usd);
		return "UserSheep";
	}
	
	@RequestMapping(path="/savesheepinfo")
	public String saveSheepData(@ModelAttribute UserSheepData usd)
	{
		usds.saveUserSheep(usd);
		return "UserHome";
	}
}















package com.mydata.mvc.service;

import com.mydata.mvc.model.UserSheepData;

public interface UserSheepDataService {
 public void saveUserSheep(UserSheepData usd);
}

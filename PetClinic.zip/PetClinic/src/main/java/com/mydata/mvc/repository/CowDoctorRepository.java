package com.mydata.mvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mydata.mvc.model.CowDoctor;
import com.mydata.mvc.model.DogDoctor;
import java.util.List;


public interface CowDoctorRepository extends JpaRepository<CowDoctor, Integer>{
	@Query("SELECT c FROM CowDoctor c Where c.name=:name")
	CowDoctor findByUsername(String name);
}

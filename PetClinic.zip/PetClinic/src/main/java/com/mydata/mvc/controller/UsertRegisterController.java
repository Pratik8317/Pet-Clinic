package com.mydata.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mydata.mvc.model.UserLogin;
import com.mydata.mvc.model.UserRegister;
import com.mydata.mvc.service.UserLoginService;
import com.mydata.mvc.service.UserRegisterService;

@Controller
@RequestMapping(path="/")
public class UsertRegisterController 
{
	// Anonymous of UserRegisterService 
	@Autowired
	UserRegisterService us;
	public void setUs(UserRegisterService us) {
		this.us = us;
	}
	
	@RequestMapping(path="/userregister")
	public String openUserRegisterForm(Model m)
	{
		UserRegister u=new UserRegister();
		m.addAttribute("user", u);
		return "UserRegister"; //UserRegister.HTML
	}
	
	@RequestMapping(path="/save")
	public String saveUserRegisterObject(@ModelAttribute UserRegister user)
	{
		user.setId(0);
		us.saveUserRegister(user);
		return "redirect:/login";   //UserLogin.HTML
	}
	
	
//	 Anonymous of UserLoginService and Setter Method
	@Autowired
	UserLoginService uls;	
	public void setUls(UserLoginService uls) 
	{
		this.uls = uls;
	}
		
	@GetMapping("/login")
    public String openLoginForm(Model model) {
        UserLogin userLogin = new UserLogin();
        model.addAttribute("userLogin", userLogin);
        return "UserLogin";
    }
	
	@PostMapping(path="/login")
	public String loginUser(@ModelAttribute UserLogin userLogin, Model m) {
	    System.out.println("Received login request: " + userLogin.getUsername());
	    boolean isValidLogin = us.validDataforLogin(userLogin.getUsername(), userLogin.getPassword());
	    System.out.println("Is valid: "+isValidLogin);
	    if (isValidLogin) {
	    	int userid=us.getUserId(userLogin.getUsername()); // to get the userid.
	    	System.out.println(userid);
	    	m.addAttribute("userid", userid);
	        return "UserHome";
	    } else {
	        return "UserLogin";
	    }
	}
	
	@GetMapping(path="/home")
    public String showHomePage() 
	{
        return "UserHome";
    }
	
	// To Open That Pet Animal Pages.
	@GetMapping(path="/usercat")
	public String showUserCat()
	{
		return "UserCat";  // UserCat.html
	}
	@GetMapping(path="/userdog")
	public String showUserDog()
	{
		return "UserDog"; // UserDog.html
	}
	@GetMapping(path="/usercow")
	public String showUserCow()
	{
		return "UserCow"; // UserCow.html
	}
	@GetMapping(path="/usersheep")
	public String showUserSheep()
	{
		return "UserSheep"; // UserSheep.html
	}
	@GetMapping(path="/doctorresponse")  // Doctor Response Page
	public String openDoctorResponsePage()
	{
		return "DoctorResponse"; //UserDoctorResponse.html
	}
	
}



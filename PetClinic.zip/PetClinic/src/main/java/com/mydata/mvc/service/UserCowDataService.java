package com.mydata.mvc.service;

import com.mydata.mvc.model.UserCowData;

public interface UserCowDataService 
{
	public void saveUserCow(UserCowData ucd);
}

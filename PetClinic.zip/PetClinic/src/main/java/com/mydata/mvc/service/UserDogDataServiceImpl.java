package com.mydata.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mydata.mvc.model.UserDogData;
import com.mydata.mvc.repository.UserDogDataRepository;

@Service
public class UserDogDataServiceImpl implements UserDogDataService
{
	@Autowired
	UserDogDataRepository uddr;

	@Override
	public void saveUserDog(UserDogData udd) {
		uddr.save(udd);
	}

}

package com.mydata.mvc.service;

import java.util.List;

import com.mydata.mvc.model.UserCatData;

public interface UserCatDataService 
{
	public void saveUserCat(UserCatData ucd);
	public List<UserCatData> getAllCatProblem();
}

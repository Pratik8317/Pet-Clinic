package com.mydata.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mydata.mvc.model.DogDoctor;
import com.mydata.mvc.repository.DogDoctorRepository;

@Service
public class DogDoctorServiceImpl implements DogDoctorService
{
	@Autowired
	DogDoctorRepository ddr;
	public void setDdr(DogDoctorRepository ddr) {
		this.ddr = ddr;
	}


	@Override
	public void saveDogDoctor(DogDoctor dd) {
		ddr.save(dd);		
	}


	@Override
	public boolean validDataforLogin(String name, String password) {
		DogDoctor dd= ddr.findByName(name);
		
		if(dd != null && dd.getPassword() != null)
		{
		return dd.getPassword().equals(password);
		}
		else
		{
			return false;
		}
	}

}

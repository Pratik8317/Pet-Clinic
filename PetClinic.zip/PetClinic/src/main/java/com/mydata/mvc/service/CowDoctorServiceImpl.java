package com.mydata.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mydata.mvc.model.CowDoctor;
import com.mydata.mvc.repository.CowDoctorRepository;

@Service
public class CowDoctorServiceImpl implements CowDoctorService{
	@Autowired
	CowDoctorRepository cdr;
	public void setCdr(CowDoctorRepository cdr) {
		this.cdr = cdr;
	}


	@Override
	public void savecowdoctor(CowDoctor cd) {
		cdr.save(cd);	
	}


	@Override
	public boolean validDataforLogin(String name, String password) {
		CowDoctor cd=cdr.findByUsername(name);
		if (cd !=null && cd.getPassword() != null) 
		{
			return cd.getPassword().equals(password);
		}
		else
		{
			return false;
		}
	}

}

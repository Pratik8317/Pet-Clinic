package com.mydata.mvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mydata.mvc.model.UserRegister;

public interface UserRegisterRepository extends JpaRepository<UserRegister, Integer>
{
	UserRegister findByUsername(String username);
}

package com.mydata.mvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mydata.mvc.model.DogDoctor;

public interface DogDoctorRepository extends JpaRepository<DogDoctor, Integer>{
	@Query("SELECT d FROM DogDoctor d WHERE d.name = :name")
	DogDoctor findByName(String name);
}

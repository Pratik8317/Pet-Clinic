package com.mydata.mvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mydata.mvc.model.CatDoctor;

public interface CatDoctorRepository extends JpaRepository<CatDoctor, Integer>
{
	 @Query("SELECT c FROM CatDoctor c WHERE c.name = :name")
	 CatDoctor findByUsername(String name);
}

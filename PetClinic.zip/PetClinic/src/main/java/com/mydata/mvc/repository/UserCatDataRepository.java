package com.mydata.mvc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mydata.mvc.model.UserCatData;

public interface UserCatDataRepository extends JpaRepository<UserCatData, Integer> 
{
	@Query("SELECT c FROM UserCatData c")
	public List<UserCatData> getAllCatProblem();
}

package com.mydata.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mydata.mvc.model.UserSheepData;
import com.mydata.mvc.repository.UserSheepDataRepository;

@Service
public class UserSheepDataServiceImpl implements UserSheepDataService
{
	@Autowired
	UserSheepDataRepository usdr;	
	public void setUsdr(UserSheepDataRepository usdr) {
		this.usdr = usdr;
	}



	@Override
	public void saveUserSheep(UserSheepData usd) {
		usdr.save(usd);	
	}

}

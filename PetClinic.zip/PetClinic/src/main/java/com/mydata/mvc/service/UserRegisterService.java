package com.mydata.mvc.service;

import com.mydata.mvc.model.UserRegister;

public interface UserRegisterService 
{
	public void saveUserRegister(UserRegister u);
	boolean validDataforLogin(String username, String password);
	//UserRegister findByUsername(String username);
	int getUserId(String username);
}

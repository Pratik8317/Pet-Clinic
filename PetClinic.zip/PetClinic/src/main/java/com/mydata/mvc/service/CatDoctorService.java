package com.mydata.mvc.service;

import com.mydata.mvc.model.CatDoctor;

public interface CatDoctorService 
{
	public void saveCatDoctor(CatDoctor cd); // for save value
	//CatDoctor findByUsername(String name);
	boolean validDataforLogin(String name, String password); // get the value
}

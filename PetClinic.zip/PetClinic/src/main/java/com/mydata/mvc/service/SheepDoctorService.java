package com.mydata.mvc.service;

import com.mydata.mvc.model.SheepDoctor;

public interface SheepDoctorService {
	public void saveSheepDoctor(SheepDoctor sd);
	boolean validDataforSheep(String name, String password);
}

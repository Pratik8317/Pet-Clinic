package com.mydata.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mydata.mvc.model.UserCowData;
import com.mydata.mvc.repository.UserCowDataRepository;

@Service
public class UserCowDataServiceImpl implements UserCowDataService{
	@Autowired
	UserCowDataRepository ucdr;	
	public void setUcdr(UserCowDataRepository ucdr) {
		this.ucdr = ucdr;
	}

	@Override
	public void saveUserCow(UserCowData ucd) {
		ucdr.save(ucd);
		
	}

}

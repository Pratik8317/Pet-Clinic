package com.mydata.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mydata.mvc.model.CatDoctor;
import com.mydata.mvc.model.UserRegister;
import com.mydata.mvc.repository.CatDoctorRepository;

@Service
public class CatDoctorServiceImpl implements CatDoctorService
{
	@Autowired
	CatDoctorRepository cdr;
	public void setCdr(CatDoctorRepository cdr) {
		this.cdr = cdr;
	}


	@Override
	public void saveCatDoctor(CatDoctor cd) {
		cdr.save(cd);
		
	}

	
	@Override
    public boolean validDataforLogin(String name, String password) {
        CatDoctor cd= cdr.findByUsername(name);

        if (cd != null && cd.getPassword() != null) 
        {  
            //System.out.println("Found user: " + user.getUsername());
            //System.out.println("User password: " + user.getPassword());

            return cd.getPassword().equals(password);
        } 
        else 
        {
            //System.out.println("User not found or password is null");
            return false;
        }
	}


	

	
	
	
}

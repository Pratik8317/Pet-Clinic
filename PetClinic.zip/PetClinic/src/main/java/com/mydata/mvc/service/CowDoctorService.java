package com.mydata.mvc.service;

import com.mydata.mvc.model.CowDoctor;

public interface CowDoctorService {
	public void savecowdoctor(CowDoctor cd);
	boolean validDataforLogin(String name, String password);
}

package com.mydata.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mydata.mvc.model.UserLogin;
import com.mydata.mvc.model.UserRegister;
import com.mydata.mvc.repository.UserLoginRepository;
import com.mydata.mvc.repository.UserRegisterRepository;

@Service
public class UserRegisterServiceImpl implements UserRegisterService
{
	@Autowired
	UserRegisterRepository ur;
	public void setUr(UserRegisterRepository ur) 
	{
		this.ur = ur;
	}

	@Override
	public void saveUserRegister(UserRegister u) {
		ur.save(u);
	}
	
	@Autowired
	UserLoginRepository ulr;
	public void setUl(UserLoginRepository ulr) {
		this.ulr = ulr;
	}
	
//	@Autowired  //*
//    public UserRegisterServiceImpl(UserRegisterRepository ur, UserLoginRepository ulr) {
//        this.ur = ur;
//        this.ulr = ulr;
//    }
	
	
	@Override
    public boolean validDataforLogin(String username, String password) {
        UserRegister user = ur.findByUsername(username);

        if (user != null && user.getPassword() != null) 
        {  
            //System.out.println("Found user: " + user.getUsername());
            //System.out.println("User password: " + user.getPassword());

            return user.getPassword().equals(password);
        } 
        else 
        {
            //System.out.println("User not found or password is null");
            return false;
        }
	}

	@Override
	public int getUserId(String username) {
		// TODO Auto-generated method stub
		UserRegister u=ur.findByUsername(username);
		return u != null ? u.getId():-1; // -1 if user not found. 
	}
}

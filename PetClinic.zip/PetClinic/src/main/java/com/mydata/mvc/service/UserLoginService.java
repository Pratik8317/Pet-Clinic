package com.mydata.mvc.service;

public interface UserLoginService 
{
	boolean validDataforLogin(String username, String password);
}

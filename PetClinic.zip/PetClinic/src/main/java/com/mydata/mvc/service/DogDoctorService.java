package com.mydata.mvc.service;

import com.mydata.mvc.model.DogDoctor;

public interface DogDoctorService {
	public void saveDogDoctor(DogDoctor dd);
	boolean validDataforLogin(String name, String password);
}

package com.mydata.mvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mydata.mvc.model.CatDoctor;
import com.mydata.mvc.model.CowDoctor;
import com.mydata.mvc.model.DogDoctor;
import com.mydata.mvc.model.SheepDoctor;
import com.mydata.mvc.model.UserCatData;
import com.mydata.mvc.model.UserLogin;
import com.mydata.mvc.service.CatDoctorService;
import com.mydata.mvc.service.CowDoctorService;
import com.mydata.mvc.service.DogDoctorService;
import com.mydata.mvc.service.SheepDoctorService;
import com.mydata.mvc.service.UserCatDataService;

@Controller
@RequestMapping(path="/")
public class DoctorController {
	
	// For Cat Doctor	
	@Autowired
	CatDoctorService cds;
	public void setCds(CatDoctorService cds) {
		this.cds = cds;
	}
	
	@RequestMapping(path="/opencatdoctor")
	public String openCatDoctor(Model m)
	{
		CatDoctor cd=new CatDoctor();
		m.addAttribute("catdoctor", cd);
		return "CatDoctor";
	}
	
	@RequestMapping(path="/savecatdoctor")
	public String saveCatDoctor(@ModelAttribute CatDoctor cd)
	{
		cd.setId(0);
		cds.saveCatDoctor(cd);
		return "redirect:/opendoctorlogin";
	}
	
	@RequestMapping("/opendoctorlogin") /// Open Login Page
	public String openloginpage(Model m)
	{
		CatDoctor cd=new  CatDoctor();
		m.addAttribute("userlogin",cd);
		return "DoctorLogin";
	}
	
	// To Open Common Doctor Page.
	@RequestMapping(path="/alldoctor")
	public String openAllDoctor(Model m)
	{
		CatDoctor cd=new CatDoctor();
		m.addAttribute("alldoctor",cd);
		return "AllDoctor";
	}
	
	// for Dog Doctor
	
	@Autowired
	DogDoctorService dds;
	public void setDds(DogDoctorService dds) {
		this.dds = dds;
	}

	@RequestMapping(path="/opendogdoctor")
	public String openDogDoctor(Model m)
	{
		DogDoctor dd=new DogDoctor();
		m.addAttribute("dogdoctor", dd);
		return "DogDoctor";
	}
	
	@RequestMapping(path="/savedogdoctor")
	public String saveDogDoctor(@ModelAttribute DogDoctor dd)
	{
		dd.setId(0);
		dds.saveDogDoctor(dd);
		return"redirect:/opendoctorlogin";
	}
	
	// For Cow Doctor
	@Autowired
	CowDoctorService cdss;
	public void setCdss(CowDoctorService cdss) {
		this.cdss = cdss;
	}

	@RequestMapping(path="/opencowdoctor")
	public String openCowDoctor(Model m)
	{
		CowDoctor cd=new CowDoctor();
		m.addAttribute("cowdoctor", cd);
		return "CowDoctor";
	}
	
	@RequestMapping(path="/savecowdoctor")
	public String saveCowDoctor(@ModelAttribute CowDoctor cd)
	{
		cd.setId(0);
		cdss.savecowdoctor(cd);
		return "redirect:/opendoctorlogin";
	}
	
	// For Sheep Doctor
	@Autowired
	SheepDoctorService sds;
	public void setSds(SheepDoctorService sds) {
		this.sds = sds;
	}
	
	@RequestMapping(path="/opensheepdoctor")
	public String openSheepDoctor(Model m)
	{
		SheepDoctor sd=new SheepDoctor();
		m.addAttribute("sheepdoctor",sd);
		return "SheepDoctor";
	}
	
	@RequestMapping(path="/savesheepdoctor")
	public String saveSheepDoctor(@ModelAttribute SheepDoctor sd)
	{
		sd.setId(0);
		sds.saveSheepDoctor(sd);
		return "redirect:/opendoctorlogin";
	}
	
	// Get Username and Password and login 
	/*@RequestMapping(path="/openDoctorLoginExternally")
	public String openDoctorLoginExternally(Model m)
	{
		CatDoctor cd=new CatDoctor();
		m.addAttribute("opencatdoctor", cd);
		return "DoctorLogin";
	}*/
	
	@RequestMapping(path="/logindoctor")
	public String loginDoctor(@ModelAttribute CatDoctor cd, @ModelAttribute DogDoctor dd, @ModelAttribute CowDoctor cowd, @ModelAttribute SheepDoctor sd, Model m) {
	    boolean isValidLogin = cds.validDataforLogin(cd.getName(), cd.getPassword());
	    boolean isdogValidLogin = dds.validDataforLogin(dd.getName(), dd.getPassword());
	    boolean iscowValidLogin = cdss.validDataforLogin(cowd.getName(), cowd.getPassword());
	    boolean issheepValidLogin= sds.validDataforSheep(sd.getName(), sd.getPassword());
	    
	    if (isValidLogin) 
	    {
	        return "redirect:/catdoctorhome";
	    } 
	    else if (isdogValidLogin) 
	    {
	        return "redirect:/dogdoctorhome";
	    } 
	    else if (iscowValidLogin) 
	    {
	        return "redirect:/cowdoctorhome";
	    } 
	    else if (issheepValidLogin) 
	    {
	        return "redirect:/sheepdoctorhome";
	    } 
	    else 
	    {
	        return "redirect:/opendoctorlogin";
	    }
	}
	
	// Doctor Home Page.
	@GetMapping(path="/catdoctorhome")  
	public String catDoctorHome(Model m)
	{
		return "CatDoctorHome";
	}
	
	@GetMapping(path="/dogdoctorhome")
	public String dogDoctorHome()
	{
		return "DogDoctorHome";
	}
	
	@GetMapping(path="/cowdoctorhome")
	public String cowDoctorHome()
	{
		return "CowDoctorHome";
	}
	
	@GetMapping(path="/sheepdoctorhome")
	public String sheepDoctorHome()
	{
		return "SheepDoctorHome";
	}
}












package com.mydata.mvc.service;

import com.mydata.mvc.model.UserDogData;

public interface UserDogDataService {
	public void saveUserDog(UserDogData udd);
}

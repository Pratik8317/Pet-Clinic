package com.mydata.mvc.model;

import java.io.Serializable;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="userregister")
public class UserRegister implements Serializable
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String ownername;
	private String username;
	private String password;
	private String mobileno;
	private String address;
	
	public void setId(int id) {
		this.id = id;
	}
	public String getOwnername() {
		return ownername;
	}
	public int getId() {
		return id;
	}
	public void setOwnername(String ownername) {
		this.ownername = ownername;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public UserRegister(int id,String ownername, String username, String password, String mobileno, String address) {
		super();
		this.id=id;
		this.ownername = ownername;
		this.username = username;
		this.password = password;
		this.mobileno = mobileno;
		this.address = address;
	}
	public UserRegister() {}
	@Override
	public String toString() {
		return "UserRegister [ownername=" + ownername + ", username=" + username + ", password=" + password
				+ ", mobileno=" + mobileno + ", address=" + address + "]";
	}
	
}

package com.mydata.mvc.model;

import java.io.Serializable;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="cowproblem")
public class UserCowData implements Serializable
{
	@Id
	private int id;
	private String name;
	private String breed;
	private String age;
	private String behavior;
	private String problem;
	public UserCowData(int id, String name, String breed, String age, String behavior, String problem) {
		super();
		this.id = id;
		this.name = name;
		this.breed = breed;
		this.age = age;
		this.behavior = behavior;
		this.problem = problem;
	}
	public UserCowData() {}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getBehavior() {
		return behavior;
	}
	public void setBehavior(String behavior) {
		this.behavior = behavior;
	}
	public String getProblem() {
		return problem;
	}
	public void setProblem(String problem) {
		this.problem = problem;
	}
	@Override
	public String toString() {
		return "UserCowData [id=" + id + ", name=" + name + ", breed=" + breed + ", age=" + age + ", behavior="
				+ behavior + ", problem=" + problem + "]";
	}
	
	
}
